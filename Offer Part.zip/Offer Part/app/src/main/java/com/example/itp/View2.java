package com.example.itp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class View2 extends AppCompatActivity {

    TextView name, discount, price, savp, vdate, clor, size;
    Button button1 , button2;

    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view2);

        name = findViewById(R.id.nam);
        discount = findViewById(R.id.dis);
        price = findViewById(R.id.pri);
        savp = findViewById(R.id.save);
        vdate = findViewById(R.id.date);
        clor = findViewById(R.id.clr);

        button1 = findViewById(R.id.btupdate);
        button2 = findViewById(R.id.btdelete);

        String nm = getIntent().getStringExtra("nm");
        String dis = getIntent().getStringExtra("dis");
        String np = getIntent().getStringExtra("np");
        String sp = getIntent().getStringExtra("sp");
        String da = getIntent().getStringExtra("da");
        String cl = getIntent().getStringExtra("cl");

        name.setText(nm);
        discount.setText(dis);
        price.setText(np);
        savp.setText(sp);
        vdate.setText(da);
        clor.setText(cl);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference refe = FirebaseDatabase.getInstance().getReference().child("Add");
                refe.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild("item")){
                            ref = FirebaseDatabase.getInstance().getReference().child("Add").child("item");
                            ref.removeValue();
                            Toast.makeText(getApplicationContext(),"Data Deleted Successfully",Toast.LENGTH_LONG).show();

                        }
                        else
                            Toast.makeText(getApplicationContext(),"No Source To Delete", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });


    }
}