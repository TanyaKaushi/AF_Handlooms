package com.example.itp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.solver.widgets.Snapshot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class ViewPage extends AppCompatActivity {

    TextView name, discount, price, savp, vdate, clor, size;
    Button button1 , button2;

    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_page);

        name = findViewById(R.id.nam);
        discount = findViewById(R.id.dis);
        price = findViewById(R.id.pri);
        savp = findViewById(R.id.save);
        vdate = findViewById(R.id.date);
        clor = findViewById(R.id.clr);
        size = findViewById(R.id.siz);

        button1 = findViewById(R.id.btnupdate);
        button2 = findViewById(R.id.btndelete);


        String nm = getIntent().getStringExtra("nm");
        String dis = getIntent().getStringExtra("dis");
        String np = getIntent().getStringExtra("np");
        String sp = getIntent().getStringExtra("sp");
        String da = getIntent().getStringExtra("da");
        String cl = getIntent().getStringExtra("cl");
        String si = getIntent().getStringExtra("si");

        name.setText(nm);
        discount.setText(dis);
        price.setText(np);
        savp.setText(sp);
        vdate.setText(da);
        clor.setText(cl);
        size.setText(si);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nam = name.getText().toString();
                String disco = discount.getText().toString();
                String npri = price.getText().toString();
                String spri = savp.getText().toString();
                String datv = vdate.getText().toString();
                String clur = clor.getText().toString();
                String siz = size.getText().toString();

                Intent i = new Intent(getApplicationContext(),Update.class);

                i.putExtra("nm",nam);
                i.putExtra("dis",disco);
                i.putExtra("np",npri);
                i.putExtra("sp",spri);
                i.putExtra("da",datv);
                i.putExtra("cl",clur);
                i.putExtra("si",siz);

                startActivity(i);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference refe = FirebaseDatabase.getInstance().getReference().child("Offer");
                refe.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild("add")){
                            ref = FirebaseDatabase.getInstance().getReference().child("Offer").child("add");
                            ref.removeValue();
                            Toast.makeText(getApplicationContext(),"Data Deleted Successfully",Toast.LENGTH_LONG).show();

                        }
                        else
                            Toast.makeText(getApplicationContext(),"No Source To Delete", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });


    }


}