package com.example.itp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class Add2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText text1, text2, text3, text4;
    TextView vdate;
    DatePickerDialog.OnDateSetListener setListener;
    Button btn1;
    Spinner colour;

    DatabaseReference ref;

    Add add;

    private void clearControls() {
        text1.setText("");
        text2.setText("");
        text3.setText("");
        text4.setText("");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add2);

        vdate = findViewById(R.id.date);
        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int[] month = {calendar.get(Calendar.MONTH)};
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        vdate.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(Add2.this, android.R.style.Theme_Holo_Dialog_NoActionBar_MinWidth, setListener, year, month[0], day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });


        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                month[0] = month[0] + 1;
                String date = day + " / " + month[0] + " / " + year;
                vdate.setText(date);

            }
        };



        Spinner aSpinner = findViewById(R.id.spin);
        aSpinner.setOnItemSelectedListener(this);

        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        text3 = findViewById(R.id.text3);
        text4 = findViewById(R.id.text4);
        colour = findViewById(R.id.spin);

        btn1 = findViewById(R.id.btn1);

        add = new Add();

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ref = FirebaseDatabase.getInstance().getReference().child("Add");

                add.setText1(text1.getText().toString().trim());
                add.setText2(text2.getText().toString().trim());
                add.setText3(text3.getText().toString().trim());
                add.setText4(text4.getText().toString().trim());
                add.setDate(vdate.getText().toString().trim());
                add.setSpinClr(colour.getSelectedItem().toString());

                //ref.push().setValue(add);
                ref.child("item").setValue(add);
                Toast.makeText(getApplicationContext(), "Data inserted Successfully", Toast.LENGTH_LONG).show();


                String name = text1.getText().toString();
                String discount = text2.getText().toString();
                String data1 = text3.getText().toString();
                String data2 = text4.getText().toString();
                String data3 = vdate.getText().toString();
                String data4 = colour.getSelectedItem().toString();

                Intent i = new Intent(getApplicationContext(), View2.class);
                clearControls();


                i.putExtra("nm",name);
                i.putExtra("dis",discount);
                i.putExtra("np",data1);
                i.putExtra("sp",data2);
                i.putExtra("da",data3);
                i.putExtra("cl",data4);

                startActivity(i);
            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}