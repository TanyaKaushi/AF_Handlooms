package com.example.itp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity3 extends AppCompatActivity {

    private Button buttonUp;
    private Button buttonAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);   buttonUp = findViewById(R.id.buttonUp);
        buttonUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { openMainActivity5(); }});

        buttonAd = findViewById(R.id.buttonAd);
        buttonAd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { openAdd2(); }});


    }


    private void openMainActivity5() {
        Intent intent = new Intent(this, MainActivity5.class);
        startActivity(intent);
    }

    private void openAdd2() {
        Intent intent = new Intent(this, Add2.class);
        startActivity(intent);
    }
}