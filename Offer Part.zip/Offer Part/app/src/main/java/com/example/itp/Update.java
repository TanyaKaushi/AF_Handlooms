package com.example.itp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Update extends AppCompatActivity {

    EditText name , discount, price , savp, vdate,clor, size;

    Button button1 , button2;

    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);


        name = findViewById(R.id.name);
        discount = findViewById(R.id.dis);
        price = findViewById(R.id.newp);
        savp = findViewById(R.id.sap);
        vdate = findViewById(R.id.da);
        clor = findViewById(R.id.clr);
        size = findViewById(R.id.siz);

        button1 = findViewById(R.id.btnUp);
        button2 = findViewById(R.id.btnDelete);

        String nm = getIntent().getStringExtra("nm");
        String dis = getIntent().getStringExtra("dis");
        String np = getIntent().getStringExtra("np");
        String sp = getIntent().getStringExtra("sp");
        String da = getIntent().getStringExtra("da");
        String cl = getIntent().getStringExtra("cl");
        String si = getIntent().getStringExtra("si");

        name.setText(nm);
        discount.setText(dis);
        price.setText(np);
        savp.setText(sp);
        vdate.setText(da);
        clor.setText(cl);
        size.setText(si);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference refe = FirebaseDatabase.getInstance().getReference().child("Offer");
                refe.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild("add")){
                            ref = FirebaseDatabase.getInstance().getReference().child("Offer").child("add");
                            ref.removeValue();
                            Toast.makeText(getApplicationContext(),"Data Deleted Successfully",Toast.LENGTH_LONG).show();

                        }
                        else
                            Toast.makeText(getApplicationContext(),"No Source To Delete", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });



        button1.setOnClickListener(new View.OnClickListener() {
            @Override


            public void onClick(View view) {
                String nm = name.getText().toString();
                String disc = discount.getText().toString();
                String np = price.getText().toString();
                String sp = savp.getText().toString();
                String da = vdate.getText().toString();
                String cl = clor.getText().toString();
                String si = size.getText().toString();

                ref = FirebaseDatabase.getInstance().getReference().child("Offer");

                HashMap hashMap = new HashMap();

                hashMap.put("txt1",nm);
                hashMap.put("txt2",disc);
                hashMap.put("txt3",np);
                hashMap.put("txt4",sp);
                hashMap.put("date",da);
                hashMap.put("spinColour",cl);
                hashMap.put("spinSize",si);

                ref.child("add").updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        Toast.makeText(getApplicationContext(),"Successfully Updated", Toast.LENGTH_LONG).show();
                       // Intent i = new Intent(getApplicationContext(), ViewPage.class);
                        //startActivity(i);
                    }
                });
            }
        });






    }
}