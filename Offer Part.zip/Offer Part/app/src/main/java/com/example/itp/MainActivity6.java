package com.example.itp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class MainActivity6 extends AppCompatActivity implements OnItemSelectedListener {

    EditText txt1, txt2, txt3, txt4;
    Spinner colour, size;
    Button btn;
    TextView Vdate;
    DatePickerDialog.OnDateSetListener setListener;

    DatabaseReference ref;

    Offer offer;


    private void clearControls() {
        txt1.setText("");
        txt2.setText("");
        txt3.setText("");
        txt4.setText("");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        Vdate = findViewById(R.id.date);
        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int[] month = {calendar.get(Calendar.MONTH)};
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        Vdate.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity6.this, android.R.style.Theme_Holo_Dialog_NoActionBar_MinWidth, setListener, year, month[0], day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });


        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                month[0] = month[0] + 1;
                String date = day + " / " + month[0] + " / " + year;
                Vdate.setText(date);

            }
        };


        Spinner aSpinner = findViewById(R.id.spin);
        aSpinner.setOnItemSelectedListener(this);

        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        txt3 = findViewById(R.id.txt3);
        txt4 = findViewById(R.id.txt4);
        colour = findViewById(R.id.spin);
        size = findViewById(R.id.spin1);

        btn = findViewById(R.id.btn);

        offer = new Offer();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ref = FirebaseDatabase.getInstance().getReference().child("Offer");

                offer.setTxt1(txt1.getText().toString().trim());
                offer.setTxt2(txt2.getText().toString().trim());
                offer.setTxt3(txt3.getText().toString().trim());
                offer.setTxt4(txt4.getText().toString().trim());
                offer.setDate(Vdate.getText().toString().trim());
                offer.setSpinColour(colour.getSelectedItem().toString());
                offer.setSpinSize(size.getSelectedItem().toString());

                //ref.push().setValue(offer);
                ref.child("add").setValue(offer);
                Toast.makeText(getApplicationContext(), "Data inserted succesfully", Toast.LENGTH_LONG).show();

                String name = txt1.getText().toString();
                String discount = txt2.getText().toString();
                String data1 = txt3.getText().toString();
                String data2 = txt4.getText().toString();
                String data3 = Vdate.getText().toString();
                String data4 = colour.getSelectedItem().toString();
                String data5= size.getSelectedItem().toString();

                Intent i = new Intent(getApplicationContext(), ViewPage.class);
                clearControls();

                i.putExtra("nm",name);
                i.putExtra("dis",discount);
                i.putExtra("np",data1);
                i.putExtra("sp",data2);
                i.putExtra("da",data3);
                i.putExtra("cl",data4);
                i.putExtra("si",data5);

                startActivity(i);

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
